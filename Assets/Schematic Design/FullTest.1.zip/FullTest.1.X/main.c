#define _XTAL_FREQ 16000000

#include <xc.h>
#include <stdint.h>
#include "mcc_generated_files/system/system.h"

// Pin definitions
#define SH_LD_LAT LATCbits.LATC4
#define SH_LD_TRIS TRISCbits.TRISC4

// UART helper
void UART_Write(char data) {
    while (!PIR3bits.TX1IF);
    TX1REG = data;
}

void UART_Write_Text(const char* text) {
    while (*text) {
        UART_Write(*text++);
    }
}

// Initialize SPI manually
void SPI_Initialize(void) {
    // Set SPI pins
    TRISC5 = 1; // SDI (data input from shift reg)
    TRISC6 = 0; // SCK (clock output)

    // Set up MSSP in SPI Master Mode, FOSC/64
    SSP1STAT = 0x40;   // CKE=1, data changes on rising edge
    SSP1CON1 = 0x20;   // Enable SSP, Master mode, FOSC/64
}

// Read from shift register using SPI
uint8_t ReadShiftRegister(void) {
    uint8_t data;

    // Pulse SH/LD low then high to latch inputs
    SH_LD_LAT = 0;
    __delay_us(1);
    SH_LD_LAT = 1;

    // Read 8 bits via SPI
    SSP1BUF = 0x00;                  // Start SPI transfer
    while (!PIR3bits.SSP1IF);        // Wait for complete
    PIR3bits.SSP1IF = 0;
    data = SSP1BUF;                  // Read result

    return data;
}

void main(void) {
    SYSTEM_Initialize();

    SH_LD_TRIS = 0;  // SH/LD as output
    SH_LD_LAT = 1;   // Default high

    SPI_Initialize();

    while (1) {
        uint8_t data = ReadShiftRegister();
        UART_Write(data);
        // Print binary representation
//        for (int i = 7; i >= 0; i--) {
//            UART_Write((data & (1 << i)) ? '1' : '0');
//        }
//        UART_Write_Text("\r\n");

        __delay_ms(200); // slow down output
    }
}
