/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RB5 aliases
#define LED2_TRIS                 TRISBbits.TRISB5
#define LED2_LAT                  LATBbits.LATB5
#define LED2_PORT                 PORTBbits.RB5
#define LED2_WPU                  WPUBbits.WPUB5
#define LED2_OD                   ODCONBbits.ODCB5
#define LED2_ANS                  ANSELBbits.ANSELB5
#define LED2_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define LED2_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define LED2_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define LED2_GetValue()           PORTBbits.RB5
#define LED2_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define LED2_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define LED2_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define LED2_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define LED2_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define LED2_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define LED2_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define LED2_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC1 aliases
#define RX_TRIS                 TRISCbits.TRISC1
#define RX_LAT                  LATCbits.LATC1
#define RX_PORT                 PORTCbits.RC1
#define RX_WPU                  WPUCbits.WPUC1
#define RX_OD                   ODCONCbits.ODCC1
#define RX_ANS                  ANSELCbits.ANSELC1
#define RX_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define RX_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define RX_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define RX_GetValue()           PORTCbits.RC1
#define RX_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define RX_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define RX_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define RX_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define RX_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define RX_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define RX_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define RX_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC3 aliases
#define TX_TRIS                 TRISCbits.TRISC3
#define TX_LAT                  LATCbits.LATC3
#define TX_PORT                 PORTCbits.RC3
#define TX_WPU                  WPUCbits.WPUC3
#define TX_OD                   ODCONCbits.ODCC3
#define TX_ANS                  ANSELCbits.ANSELC3
#define TX_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define TX_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define TX_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define TX_GetValue()           PORTCbits.RC3
#define TX_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define TX_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define TX_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define TX_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define TX_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define TX_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define TX_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define TX_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define CLK_TRIS                 TRISCbits.TRISC4
#define CLK_LAT                  LATCbits.LATC4
#define CLK_PORT                 PORTCbits.RC4
#define CLK_WPU                  WPUCbits.WPUC4
#define CLK_OD                   ODCONCbits.ODCC4
#define CLK_ANS                  ANSELCbits.ANSELC4
#define CLK_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define CLK_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define CLK_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define CLK_GetValue()           PORTCbits.RC4
#define CLK_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define CLK_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define CLK_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define CLK_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define CLK_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define CLK_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define CLK_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define CLK_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define QH_TRIS                 TRISCbits.TRISC5
#define QH_LAT                  LATCbits.LATC5
#define QH_PORT                 PORTCbits.RC5
#define QH_WPU                  WPUCbits.WPUC5
#define QH_OD                   ODCONCbits.ODCC5
#define QH_ANS                  ANSELCbits.ANSELC5
#define QH_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define QH_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define QH_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define QH_GetValue()           PORTCbits.RC5
#define QH_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define QH_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define QH_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define QH_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define QH_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define QH_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define QH_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define QH_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define LATC6_TRIS                 TRISCbits.TRISC6
#define LATC6_LAT                  LATCbits.LATC6
#define LATC6_PORT                 PORTCbits.RC6
#define LATC6_WPU                  WPUCbits.WPUC6
#define LATC6_OD                   ODCONCbits.ODCC6
#define LATC6_ANS                  ANSELCbits.ANSELC6
#define LATC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define LATC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define LATC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define LATC6_GetValue()           PORTCbits.RC6
#define LATC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define LATC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define LATC6_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define LATC6_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define LATC6_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define LATC6_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define LATC6_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define LATC6_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/