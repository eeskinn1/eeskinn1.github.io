#include <xc.h>
#include <stdint.h>
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/eusart1.h"
#include <string.h>
#include <stdio.h>
#include "mcc_generated_files/timer/tmr1_deprecated.h"

// Pin Definitions
#define SH_LD_LAT    LATCbits.LATC4
#define SH_LD_TRIS   TRISCbits.TRISC4
#define LED1_LAT     LATBbits.LATB3
#define LED1_TRIS    TRISBbits.TRISB3
#define IR1_LAT   LATBbits.LATB4  // D3
#define IR2_LAT   LATBbits.LATB2  // D2
#define IR3_LAT   LATBbits.LATB1  // D1
#define IR4_LAT   LATBbits.LATB0  // D0
#define IR1_TRIS  TRISBbits.TRISB4
#define IR2_TRIS  TRISBbits.TRISB2
#define IR3_TRIS  TRISBbits.TRISB1
#define IR4_TRIS  TRISBbits.TRISB0

volatile uint8_t speed_ready = 0;
volatile uint8_t last_speed_value = 0;
volatile uint32_t last_speed_send_time = 0;

volatile uint32_t sensor1_time = 0;
volatile uint32_t sensor3_time = 0;
volatile uint32_t sensor2_time = 0;
volatile uint32_t sensor4_time = 0;
volatile uint8_t sensor1_triggered = 0;
volatile uint8_t sensor3_triggered = 0;
volatile uint8_t sensor2_triggered = 0;
volatile uint8_t sensor4_triggered = 0;
#define MIN_SPEED 1.0f    // Minimum speed to report (inches/sec)
#define MAX_SPEED 99.0f   // Maximum speed we can represent with 2 digits
#define SENSOR_DISTANCE 2 // Distance between sensor pairs in inches

//#define _XTAL_FREQ 16000000

uint16_t ms = 0;
uint16_t sec = 0;

void timer_callback(void) {
    ms++;
    if (ms >= 1000) {
        ms -= 1000;
        sec++;
        LED1_Toggle();
    }
}

void eusart_callback(void) {
    // Can be used for interrupt-based reception
}

// === UART Send One Byte ===
void UART_Write(uint8_t data) {
    while (!PIR3bits.TX1IF);  // Wait for TX buffer empty
    TX1REG = data;
}

uint8_t send_message(char *my_message) {
    printf("%s\n", my_message);
    return 1;
}

// === SPI Setup ===
void SPI_Initialize(void) {
    TRISC5 = 1;  // SDI
    TRISC6 = 0;  // SCK
    SSP1STAT = 0x40;   // CKE = 1 (data changes on rising edge)
    SSP1CON1 = 0x20;   // SSPEN = 1, Master mode, FOSC/4
}

// === Read One Byte from Shift Register ===
uint8_t ReadShiftRegister(void) {
    // Latch parallel inputs into shift register
    SH_LD_LAT = 0;
    __delay_us(1);
    SH_LD_LAT = 1;
    
    // Begin SPI read
    SSP1BUF = 0x00;
    while (!PIR3bits.SSP1IF);  // Wait until transfer complete
    PIR3bits.SSP1IF = 0;
    return SSP1BUF;
}

#define BUFSIZE 4
#define MSGSIZE 64
#define TEAMSIZE 5
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

// Message format: AZ[sender][receiver][command][data]YB
// Example: AZENR1YB - from E to N with command R1 (Reset)

// Message command types
#define CMD_RESET "R1"   // Reset command
#define CMD_READY "RD"   // Ready status
#define CMD_DATA  "DT"   // Data transfer
#define CMD_ERROR "F"    // Error message (followed by error code)

const char my_id = 'E';
const char team_ids[TEAMSIZE + 1] = "NEKHX";  // X is broadcast
char buffer_in[BUFSIZE + 1];
char message_in[MSGSIZE + 1];
char message_out[MSGSIZE + 1];

void fill_string(char *mystring, char value, unsigned int size) {
    for (int i = 0; i < size; i++) {
        mystring[i] = value;
    }
}

unsigned int find_char(const char *mystring, char value, unsigned int size) {
    for (int i = 0; i < size; i++) {
        if (mystring[i] == value) {
            return 1;
        }
    }
    return 0;
}

// Create a formatted outgoing message
void format_message(char *dest, char target_id, const char *cmd, const char *data) {
    sprintf(dest, "AZ%c%c%s%sYB", my_id, target_id, cmd, data);
}

// Send an error message
void send_error(char target_id, char error_code) {
    char error_msg[MSGSIZE + 1];
    char err_data[2] = {error_code, '\0'};
    format_message(error_msg, target_id, CMD_ERROR, err_data);
    send_message(error_msg);
}

// Function to send sensor low message for a specific sensor
void send_sensor_low(uint8_t sensor_num) {
    char message[MSGSIZE + 1];
    
    // Format: AZEHS0XYB
    // Where: 
    //   E = sender ID (your device)
    //   H = receiver (change if needed)
    //   S = sensor command
    //   0 = low state (fixed)
    //   X = sensor number (1-4)
    
    //sprintf(message, "AZ%cNS0%01dYB", my_id, sensor_num);
    //send_message(message);
    
    // Optional: Turn on corresponding IR LED
    switch(sensor_num) {
        case 1: __delay_ms(25); IR1_LAT = 0; Dom_SetHigh(); __delay_ms(500); IR1_LAT = 1; break;
        case 2: __delay_ms(25); IR3_LAT = 0; Dom_SetHigh(); __delay_ms(500); IR3_LAT = 1; break;
        //case 3: __delay_ms(1000); IR3_LAT = 1; break;
        //case 4: __delay_ms(25); IR3_LAT = 0; Dom_SetLow(); __delay_ms(500); IR3_LAT = 1; break;
    }
}

void calculate_and_send_speed(uint8_t first_sensor, uint8_t second_sensor) {
    uint32_t time_diff_ms = 0;
    float speed_inches_per_sec = 0.0;

    // Calculate based on which sensor pair was triggered
    if (first_sensor == 1 && second_sensor == 3) {
        if (sensor1_triggered && sensor3_triggered) {
            // Add check for valid time difference
            if (sensor3_time > sensor1_time) {
                time_diff_ms = sensor3_time - sensor1_time;
                // DEBUG: Print time difference between sensor 1 and 3
                char debug_msg[MSGSIZE + 1];
                //sprintf(debug_msg, "DEBUG: S1-S3 time: %lums", time_diff_ms);
                //send_message(debug_msg);
            }
            sensor1_triggered = 0;
            sensor3_triggered = 0;
        } else {
            return;
        }
    } 
    else if (first_sensor == 2 && second_sensor == 4) {
        if (sensor2_triggered && sensor4_triggered) {
            // Add check for valid time difference
            if (sensor4_time > sensor2_time) {
                time_diff_ms = sensor4_time - sensor2_time;
            }
            sensor2_triggered = 0;
            sensor4_triggered = 0;
        } else {
            return;
        }
    } else {
        return;
    }

    if (time_diff_ms > 0) {
        speed_inches_per_sec = (SENSOR_DISTANCE / (time_diff_ms / 1000.0));
        last_speed_value = (uint8_t)(speed_inches_per_sec + 0.5f);
        if (last_speed_value < 1) last_speed_value = 1;
        if (last_speed_value > 99) last_speed_value = 99;
        speed_ready = 1;
    }
}

// Sensor checking function with edge detection
void check_sensors(void) {
    static uint8_t last_state = 0xFF;
    uint8_t current_state = ReadShiftRegister();
    
    if (current_state != last_state) {
        for (uint8_t i = 0; i < 4; i++) {
            uint8_t mask;
            switch(i) {
                case 0: mask = 0x80; break;
                case 1: mask = 0x04; break;
                case 2: mask = 0x02; break;
                case 3: mask = 0x01; break;
            }
            
            if ((current_state & mask) == 0 && (last_state & mask)) {
                uint32_t current_time = (sec * 1000) + ms;
                
                switch(i+1) {
                    case 1: 
                        sensor1_time = current_time;
                        sensor1_triggered = 1;
                        break;
                    case 2: 
                        sensor2_time = current_time;
                        sensor2_triggered = 1;
                        break;
                    case 3: 
                        sensor3_time = current_time;
                        sensor3_triggered = 1;
                        break;
                    case 4: 
                        sensor4_time = current_time;
                        sensor4_triggered = 1;
                        break;
                }
                
                send_sensor_low(i+1);
                
                if (sensor1_triggered && sensor3_triggered) {
                    calculate_and_send_speed(1, 3);
                }
                if (sensor2_triggered && sensor4_triggered) {
                    calculate_and_send_speed(2, 4);
                }
            }
        }
        last_state = current_state;
    }

    // Send speed once per second if ready
    uint32_t current_time = (sec * 1000) + ms;
    if (speed_ready && (current_time - last_speed_send_time >= 1000)) {
        char speed_message[MSGSIZE + 1];
        sprintf(speed_message, "AZEDV%02dYB", last_speed_value);
        send_message(speed_message);
        speed_ready = 0;
        last_speed_send_time = current_time;
    }
}

// Handle received messages
uint8_t handle_message(unsigned int msg_length) {
    // Null-terminate the message for string operations
    message_in[msg_length] = 0;
    
    // Extract message parts
    char sender = message_in[2];
    char receiver = message_in[3];
    char cmd_type[3] = {message_in[4], message_in[5], '\0'};
    
    printf("PIC: handling message from %c to %c, command %s\n", sender, receiver, cmd_type);
    
    // Handle different command types
    if (strcmp(cmd_type, "R1") == 0) {
        printf("PIC: Master Reset Received\n");
        // For reset broadcast, forward the original message exactly as received
        if (sender == 'K' && receiver == 'X') {
            // Original reset broadcast message is forwarded as-is
            printf("%s", message_in);
        } else {
            // For direct resets, send acknowledgment
            char response[MSGSIZE + 1];
            //format_message(response, sender, CMD_RESET, "ACK");
            //send_message(response);
        }
        
        // Visual feedback
        for (int j = 0; j < 2; j++) {
            LED2_SetHigh();
            __delay_ms(200);
            LED2_SetLow();
            __delay_ms(200);
            
        }
        return 1;
    }
    else if (strcmp(cmd_type, "RD") == 0) {
//        printf("PIC: Ready Status Request\n");
        
        // Send ready status with current timer value
        char data[10];
        sprintf(data, "%d", sec);
        
        char response[MSGSIZE + 1];
        //format_message(response, sender, CMD_READY, data);
        //send_message(response);
        return 1;
    }
    else if (strcmp(cmd_type, "DT") == 0) {
        // Handle data transfer message
//        printf("PIC: Data received: %s\n", message_in + 6);
        
        
        // Acknowledge receipt
        char response[MSGSIZE + 1];
        format_message(response, sender, CMD_DATA, "ACK");
     //   send_message(response);
        return 1;
    }
    else if (cmd_type[0] == 'F') {
        // Error message received
//        printf("PIC: Error code %c received from %c\n", message_in[5], sender);
        send_message(message_in);
        return 1;
    }
    
    // Unknown command
//    printf("PIC: Unknown command type\n");
    send_error(sender, '9'); // Error code 9 for unknown command
    return 0;
}

int main(void) {
    char c = 0;
    unsigned int buffer_ii = 0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii = 0;
    unsigned int message_last_ii = 0;
    unsigned int message_incoming = 0;
    unsigned int potential_message_start = 0;  // Flag for tracking 'A' character
    
    // Initialize buffers
    buffer_in[BUFSIZE] = 0;
    message_in[MSGSIZE] = 0;
    fill_string(buffer_in, 'a', BUFSIZE);
    fill_string(message_in, '_', MSGSIZE);
    message_in[MSGTESTSIZE] = MSGTESTCHAR;
    
    // Initialize system
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    // Initialize timer
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();
    TMR1_OverflowCallbackRegister(timer_callback);
    
    // Initialize UART
    EUSART1_Initialize();
    EUSART1_Enable();
    EUSART1_RxCompleteCallbackRegister(eusart_callback);
    
    // Configure SH/LD and LED1
    SH_LD_TRIS = 0;
    SH_LD_LAT = 1;
    LED1_TRIS = 0;
    LED1_LAT = 0;
    
    // Configure IR output pins
    IR1_TRIS = 0;
    IR2_TRIS = 0;
    IR3_TRIS = 0;
    IR4_TRIS = 0;
    
    // Initialize IR outputs low
    IR1_LAT = 0;
    IR2_LAT = 0;
    IR3_LAT = 0;
    IR4_LAT = 0;
    
    // Initialize SPI
    SPI_Initialize();
       
    while (1) {
        // Read shift register data and set IR outputs
        uint8_t data = ReadShiftRegister();
 //       UART_Write(data);
        
 //       printf("AZEXF3YB");
        
        // Set each IR output HIGH if its corresponding sensor bit is LOW
//        IR1_LAT = (data & 0x80);  // D3
//        IR2_LAT = !(data & 0x04);  // D2
//        IR3_LAT = !(data & 0x02);  // D1
//        IR4_LAT = (data & 0x01);  // D0
        
        check_sensors();
        
        
        
        if (EUSART1_IsRxReady()) {
            c = EUSART1_Read();
            buffer_in[buffer_ii] = c;
            
            // Track potential message start with 'A'
            if (buffer_in[buffer_ii] == 'A') {
                potential_message_start = 1;
            }
            // Check for valid message start "AZ"
            else if (potential_message_start && buffer_in[buffer_last_ii] == 'A' && buffer_in[buffer_ii] == 'Z') {
//                printf("PIC: Valid message start detected\n");
                fill_string(message_in, '_', MSGSIZE);
                message_in[MSGTESTSIZE] = MSGTESTCHAR;
                message_incoming = 1;
                message_in[0] = buffer_in[buffer_last_ii]; // Store 'A'
                message_in[1] = buffer_in[buffer_ii];      // Store 'Z'
                message_ii = 2;
                potential_message_start = 0;
            }
            // Check for invalid message start sequence with 'A'
            else if (potential_message_start && buffer_in[buffer_last_ii] == 'A' && buffer_in[buffer_ii] != 'Z') {
//                printf("PIC: Error 1: Invalid message start 'A%c'\n", buffer_in[buffer_ii]);
                send_error('X', '1');  // Send error code 1 for invalid message start
                potential_message_start = 0;
            }
            // Handle any incorrect first character (not A)
            else if (buffer_in[buffer_ii] != 'A' && buffer_in[buffer_ii] == 'Z' && buffer_in[buffer_last_ii] != 'A') {
//                printf("PIC: Error 1: Invalid first character '%c'\n", buffer_in[buffer_last_ii]);
                send_error('X', '1');  // Send error code 1 for invalid message start
            }
            
            // Detect message end sequence "YB"
            else if (message_incoming && buffer_in[buffer_last_ii] == 'Y' && buffer_in[buffer_ii] == 'B') {
//                printf("PIC: message end detected\n");
                message_incoming = 0;
                message_in[message_ii - 1] = buffer_in[buffer_last_ii]; // Store 'Y'
                message_in[message_ii] = buffer_in[buffer_ii];          // Store 'B'
                message_ii++;
                
                // Check if we sent this message (loops in communication channels)
                if (message_in[2] == my_id) {
//                    printf("PIC: message from self, ignoring\n");
                }
                // Check if message is for us or broadcast (X)
                else if (message_in[3] == my_id || message_in[3] == 'X') {
                    handle_message(message_ii);
                }
                // Forward messages not intended for us
                else {
//                    printf("PIC: message not for me, forwarding\n");
                    message_in[message_ii] = '\0'; // Ensure null termination
                    send_message(message_in);
                }
                
                // Reset message index for next message
                message_ii = 0;
            }
            
            // Store message characters
            else if (message_incoming) {
                message_in[message_ii] = buffer_in[buffer_ii];
                
                if (message_ii >= 5 && message_in[message_ii-1] == 'Y' && message_in[message_ii] != 'B') {
                    // We got a 'Y' not followed by 'B'
//                    printf("PIC: Error 3: Incomplete stop sequence (expected YB)\n");
                    send_error('X', '3');
                    message_incoming = 0;
                    message_ii = 0;
                    continue;
                }
                
                // Validate sender on 3rd character (index 2)
                if (message_ii == 2) {
                    if (find_char(team_ids, message_in[message_ii], TEAMSIZE)) {
//                        printf("PIC: sender in team\n");
                    } else {
//                        printf("PIC: Error 2: Sender not in team\n");
                        send_error('X', '2'); // Error code 2 for invalid sender
                        message_incoming = 0;
                        message_ii = 0;
                        continue;
                    }
                }
                
                // Validate receiver on 4th character (index 3)
                if (message_ii == 3) {
                    if (find_char(team_ids, message_in[message_ii], TEAMSIZE)) {
//                        printf("PIC: receiver in team\n");
                    } else {
//                        printf("PIC: Error 3: Receiver not in team\n");
                        send_error('X', '3'); // Error code 3 for invalid receiver
                        message_incoming = 0;
                        message_ii = 0;
                        continue;
                    }
                }
                
                message_last_ii = message_ii;
                message_ii++;
                
                // Check for message overflow
                if (message_ii >= MSGSIZE - 1) {
//                    printf("PIC: Error 5: Message too large, discarding\n");
                    send_error('X', '5'); // Broadcast error 5 for message too large
                    message_incoming = 0;
                    message_ii = 0;
                }
            }
            
            // Update buffer indices
            buffer_last_ii = buffer_ii;
            buffer_ii = (buffer_ii + 1) % BUFSIZE;
        }
    }
}